package com.qa.hubspot.pages;

import org.openqa.selenium.WebDriver;

public class DealsPage extends BasePage{
	
	WebDriver driver;
	public DealsPage(WebDriver driver){
		this.driver = driver;
	}

	
}
